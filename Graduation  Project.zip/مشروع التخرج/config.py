Configuration constants (edit values as needed)

EDGE_UNIT_ID = "edge_unit_02"
HEALTH_INTERVAL = 30
DROP_FOLDER = "drop_here2"
PROCESSED_FOLDER = "processed2"
MODEL_PATH = "yolo12sconf.pt" # put your model file here or change path
BACKEND_URL = "https://etvds.app/api/violations"
API_KEY = "def456"
TCP_HOST = "10.10.10.3"
TCP_PORT = 5000
DB_PATH = "plates.db"
DISTANCE_METERS = 1000
SPEED_LIMIT_KMH = 100
CONF_THRESHOLD = 0.3
PLATE_TTL_SECONDS = int((DISTANCE_METERS / (SPEED_LIMIT_KMH / 3.6)) * 1.3)