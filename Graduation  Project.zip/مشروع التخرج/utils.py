import os
import string
from datetime import datetime, timezone
from config import PROCESSED_FOLDER

allowed_chars = string.ascii_uppercase + string.digits

def iso_now():
return datetime.now(timezone.utc).isoformat()

def move_file_to_processed(path):
os.makedirs(PROCESSED_FOLDER, exist_ok=True)
basename = os.path.basename(path)
dest = os.path.join(PROCESSED_FOLDER, basename)
try:
os.replace(path, dest)
except FileNotFoundError:
pass
return dest

def filter_plate_text(text):
if not text:
return None
return ''.join([c for c in str(text).upper() if c in allowed_chars])