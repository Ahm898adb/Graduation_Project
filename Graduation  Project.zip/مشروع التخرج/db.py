import sqlite3
from config import DB_PATH

def init_db():
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS incoming_plates(
plate TEXT,
timestamp TEXT,
received_at TEXT DEFAULT CURRENT_TIMESTAMP
)
""")
conn.commit()
conn.close()

def insert_plate(plate, timestamp):
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()
cursor.execute("INSERT INTO incoming_plates(plate, timestamp) VALUES (?, ?)", (plate, timestamp))
conn.commit()
conn.close()