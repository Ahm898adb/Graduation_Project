import requests
import asyncio
from config import BACKEND_URL, API_KEY

async def post_violation_async(image_path, plate_text, timestamp, violation_type):
data = {"plate": plate_text, "timestamp": timestamp, "violation": violation_type}
headers = {"X-Api-Key": API_KEY}
try:
def do_post():
with open(image_path, "rb") as f:
files = {"image": f}
return requests.post(BACKEND_URL, data=data, files=files, headers=headers, timeout=10)
resp = await asyncio.get_event_loop().run_in_executor(None, do_post)
if resp.status_code == 200:
print(f"[BACKEND] Violation posted: {plate_text}")
else:
print(f"[BACKEND] Post failed: {resp.status_code} {resp.text}")
except Exception as e:
print(f"[BACKEND] Post error: {e}")