import os
import asyncio
from config import DROP_FOLDER

async def watch_folder(image_queue, processing_files):
print("[WATCHER] Watching:", DROP_FOLDER)
while True:
try:
files = [f for f in os.listdir(DROP_FOLDER) if f.lower().endswith((".jpg", ".jpeg", ".png"))]
for file in files:
full_path = os.path.join(DROP_FOLDER, file)
if full_path in processing_files:
continue
processing_files.add(full_path)
await image_queue.put(full_path)
except Exception as e:
print(f"[WATCHER] Error: {e}")
await asyncio.sleep(1)
health.py

import requests
import asyncio
from config import HEALTH_INTERVAL, API_KEY

async def health_ping_loop():
while True:
try:
def do_ping():
return requests.post(
"https://etvds.app/api/edge/health",
headers={"X-Api-Key": API_KEY},
timeout=5
)
resp = await asyncio.get_event_loop().run_in_executor(None, do_ping)
if resp.status_code == 200:
print("[HEALTH] Ping OK")
else:
print(f"[HEALTH] Ping failed: {resp.status_code}")
except Exception as e:
print(f"[HEALTH] Ping error: {e}")
await asyncio.sleep(HEALTH_INTERVAL)