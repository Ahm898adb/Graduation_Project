import asyncio
from db import init_db
from tcp_client import TCPClient
from watcher import watch_folder
from health import health_ping_loop
from processor import process_image

image_queue = asyncio.Queue()
processing_files = set()

async def worker(tcp_client):
while True:
path = await image_queue.get()
try:
await process_image(path, tcp_client)
except Exception as e:
print(f"[WORKER] Error processing {path}: {e}")
processing_files.discard(path)
finally:
image_queue.task_done()

async def main():
init_db()
tcp_client = TCPClient()
await tcp_client.connect()
reasonml

asyncio.create_task(watch_folder(image_queue, processing_files))
asyncio.create_task(health_ping_loop())

for _ in range(3):
    asyncio.create_task(worker(tcp_client))

await asyncio.Future()  # run forever

if name == "main":
try:
asyncio.run(main())
except KeyboardInterrupt:
print("Shutting down...")
