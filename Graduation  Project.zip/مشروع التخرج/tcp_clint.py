import asyncio
import json
from config import TCP_HOST, TCP_PORT

class TCPClient:
def init(self, host=TCP_HOST, port=TCP_PORT):
self.host = host
self.port = port
self.writer = None
self.reader = None

async def connect(self):
    if self.writer:
        return
    try:
        self.reader, self.writer = await asyncio.open_connection(self.host, self.port)
        print(f"[TCP] Connected to {self.host}:{self.port}")
    except Exception as e:
        print(f"[TCP] Connect error: {e}")
        self.writer = None

async def send(self, payload: dict):
    if not self.writer:
        await self.connect()
        if not self.writer:
            print("[TCP] Not connected, dropping payload")
            return
    try:
        data = (json.dumps(payload) + "\n").encode()
        self.writer.write(data)
        await self.writer.drain()
        print(f"[TCP] Sent: {payload}")
    except Exception as e:
        print(f"[TCP] Send error: {e}")
        try:
            self.writer.close()
            await self.writer.wait_closed()
        except Exception:
            pass
        self.writer = None

async def close(self):
    if self.writer:
        self.writer.close()
        await self.writer.wait_closed()
        self.writer = None