Simple edge service that watches a folder for images, runs YOLO + OCR to read license plates, stores plates in a local SQLite DB and can post violations to a backend or send plate data over TCP.

How to use:

    Edit config.py values as needed.
    Create a Python virtual environment:
    python3 -m venv venv
    source venv/bin/activate
    Install requirements:
    pip install -r requirements.txt
    Run:
    python main.py

Notes:

    Put your YOLO model file at the path specified in config.py (MODEL_PATH).
    Adjust API_KEY, BACKEND_URL, TCP_HOST, etc. before deploying.
    Seatbelt detection is left as a placeholder in processor.py.
