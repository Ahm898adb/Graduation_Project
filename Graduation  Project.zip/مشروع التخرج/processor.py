import os
import cv2
import asyncio
from ultralytics import YOLO
from fast_plate_ocr import LicensePlateRecognizer
from utils import iso_now, move_file_to_processed, filter_plate_text
from db import insert_plate
from config import CONF_THRESHOLD, MODEL_PATH
from backend import post_violation_async
Initialize models once

model = YOLO(MODEL_PATH)
ocr = LicensePlateRecognizer('cct-s-v1-global-model')

async def process_image(path, tcp_client):
iso_timestamp = iso_now()
plate_text = None
violations_posted = []
pgsql

try:
    results = model(path)
    for r in results:
        boxes = getattr(r, "boxes", None)
        if not boxes:
            continue
        for box in boxes:
            # get confidence
            conf = 1.0
            try:
                conf = float(getattr(box, "conf", 1.0).cpu().numpy())
            except Exception:
                try:
                    conf = float(box.conf)
                except Exception:
                    conf = 1.0
            if conf < CONF_THRESHOLD:
                continue

            # get coordinates
            try:
                xy = getattr(box, "xyxy", None)
                coords = xy.cpu().numpy()[0]
                x1, y1, x2, y2 = map(int, coords)
            except Exception:
                try:
                    coords = box.xyxy[0]
                    x1, y1, x2, y2 = map(int, coords)
                except Exception:
                    continue

            img = cv2.imread(path)
            if img is None:
                continue
            h, w = img.shape[:2]
            x1 = max(0, min(x1, w-1))
            x2 = max(0, min(x2, w-1))
            y1 = max(0, min(y1, h-1))
            y2 = max(0, min(y2, h-1))
            if x2 <= x1 or y2 <= y1:
                continue

            crop = img[y1:y2, x1:x2]
            # OCR (run in executor if blocking)
            try:
                ocr_res = await asyncio.get_event_loop().run_in_executor(None, lambda: ocr.detect_plate(crop))
            except Exception as e:
                print(f"[OCR] Error: {e}")
                ocr_res = None

            if ocr_res:
                plate_raw = None
                try:
                    plate_raw = getattr(ocr_res[0], "plate", None)
                except Exception:
                    try:
                        plate_raw = ocr_res[0][0]
                    except Exception:
                        plate_raw = None

                plate_text = filter_plate_text(plate_raw)
                if plate_text:
                    insert_plate(plate_text, iso_timestamp)
                    break
        if plate_text:
            break

    # Placeholder for seatbelt detection logic
    seatbelt_violation = False

    if seatbelt_violation and plate_text and os.path.exists(path):
        await post_violation_async(path, plate_text, iso_timestamp, "NO_SEATBELT")
        violations_posted.append("NO_SEATBELT")

    if plate_text:
        await tcp_client.send({"plate": plate_text, "timestamp": iso_timestamp})

    # Logging
    if violations_posted:
        print(f"[PROCESS] Violations for {plate_text}: {violations_posted}")
    elif not plate_text:
        print(f"[PROCESS] No plate for {path}")
    elif not seatbelt_violation:
        print(f"[PROCESS] No violations for {plate_text}")

except Exception as e:
    print(f"[PROCESS] Error processing {path}: {e}")
finally:
    move_file_to_processed(path)
